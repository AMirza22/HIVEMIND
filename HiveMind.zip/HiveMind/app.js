const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const bcrypt = require('bcrypt');
const path = require('path');
require('dotenv').config();
const User = require('./models/User');

const app = express();

// DB connection
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.use(express.json());


app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
}));

app.use((req, res, next) => {
  res.locals.user = req.session.user;
  next();
});

// Routes
const authRoutes = require('./routes/auth');
const observerRoutes = require('./routes/observer');
const supportRoutes = require('./routes/support');
const accountRoutes = require('./routes/account');
const messageRoutes = require('./routes/message');
const observationRoutes = require('./routes/observations');


app.use('/', authRoutes);
app.use('/observer', observerRoutes);
app.use('/support', supportRoutes);
app.use('/account', accountRoutes);
app.use('/messages', messageRoutes);
app.use('/observations', observationRoutes);


(async () => {
  const existing = await User.findOne({ username: 'observer@test.com' });
  if (!existing) {
    const hashed = await bcrypt.hash('observer123', 10);

    const cardNumber = '1111222233334444';
    const cvv = '123';
    const cardLast4 = cardNumber.slice(-4);
    const cardFirst12 = cardNumber.slice(0, 12);

    const cardHash = await bcrypt.hash(cardFirst12, 10);
    const cvvHash = await bcrypt.hash(cvv, 10);

    await User.create({
      username: 'observer@test.com',
      password: hashed,
      category: 'observer',
      forename: 'Test',
      surname: 'Observer',
      phone: '0123456789',
      line1: '123 Example St',
      postcode: 'EX1 2PL',
      city: 'Testville',
      country: 'Testland',
      cardInfo: {
        accountName: 'Test Observer',
        accountNumber: '12345678',
        sortCode: '12-34-56',
        cardLast4,
        cardHash,
        cvvHash
      }
    });
    console.log('✅ Sample observer account created');
  }

  const support = await User.findOne({ username: 'support@test.com' });
  if (!support) {
    const hashed = await bcrypt.hash('support123', 10);
    await User.create({
      username: 'support@test.com',
      password: hashed,
      category: 'support',
      forename: 'Support',
      surname: 'User',
      phone: '0987654321'
    });
    console.log('✅ Sample support account created');
  }
})();


app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});
