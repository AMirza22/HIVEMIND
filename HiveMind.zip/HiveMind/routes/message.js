const express = require('express');
const router = express.Router();
const Message = require('../models/Message');
const User = require('../models/User');
const { isAuthenticated } = require('../middleware/authMiddleware');

// GET message inbox for current user
router.get('/', isAuthenticated, async (req, res) => {
  const currentUserId = req.session.user._id;

  // Get all messages involving this user
  const messages = await Message.find({
    $or: [{ from: currentUserId }, { to: currentUserId }]
  }).populate('from').populate('to');

  // Build a unique list of users you've messaged with
  const contactsMap = new Map();
  messages.forEach(msg => {
    const otherUser = msg.from._id.equals(currentUserId) ? msg.to : msg.from;
    contactsMap.set(otherUser.username, otherUser); // use username as key
  });
  const contacts = Array.from(contactsMap.values());

  // 🔥 Get last 5 messages received
  const recentMessages = await Message.find({ to: currentUserId })
    .populate('from')
    .sort({ sentAt: -1 })
    .limit(5);

  res.render('messages/conversations', {
    contacts,
    recentMessages,
    user: req.session.user
  });
});

  // POST new message
  router.post('/', isAuthenticated, async (req, res) => {
      const { toEmail, message } = req.body;
      
      const recipient = await User.findOne({ username: toEmail });
      
      if (!recipient) {
          return res.status(404).send('Recipient not found');
        }
        
        const msg = new Message({
            from: req.session.user._id,
            to: recipient._id,
            message
        });
        
        await msg.save();
        res.redirect('/messages');
    });
    
    router.get('/new', isAuthenticated, async (req, res) => {
      const users = await User.find({ _id: { $ne: req.session.user._id } }); // exclude self
      res.render('messages/new-chat', {
        users,
        user: req.session.user
      });
    });
    
    router.post('/new', isAuthenticated, async (req, res) => {
      const target = await User.findOne({ username: req.body.username });
      if (!target) return res.status(404).send('User not found');
      res.redirect(`/messages/${target.username}`);
    });
    
    router.get('/:username', isAuthenticated, async (req, res) => {
    const currentUser = req.session.user;
    const contact = await User.findOne({ username: req.params.username });
  
    if (!contact) return res.status(404).send('User not found');
  
    const messages = await Message.find({
      $or: [
        { from: currentUser._id, to: contact._id },
        { from: contact._id, to: currentUser._id }
      ]
    }).sort({ sentAt: 1 }).populate('from');
  
    res.render('messages/chat', {
      messages,
      contact,
      currentUser,
      user: req.session.user
    });
  });

  router.post('/:username', isAuthenticated, async (req, res) => {
    const contact = await User.findOne({ username: req.params.username });
  
    if (!contact) return res.status(404).send('Recipient not found');
  
    const msg = new Message({
      from: req.session.user._id,
      to: contact._id,
      message: req.body.message,
    });
  
    await msg.save();
    res.redirect(`/messages/${contact.username}`);
  });
  
  


module.exports = router;