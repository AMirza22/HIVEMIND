const express = require("express");
const router = express.Router();
const User = require("../models/User");
const bcrypt = require("bcrypt");

router.get("/", (req, res) => {
  if (!req.session.user) {
    return res.redirect("/login");
  }

  if (req.session.user.category === "observer") {
    return res.redirect("/observer/dashboard");
  }

  if (req.session.user.category === "support") {
    return res.redirect("/support/dashboard");
  }

  res.redirect("/login");
});


// Register
router.get("/register", (req, res) => {
  res.render("auth/register");
});

router.post("/register", async (req, res) => {
  const { username, password, forename, surname, phone } = req.body;

  const hashed = await bcrypt.hash(password, 10);

  const fullCard = req.body.cardNumber || '';
  const cvv = req.body.cvv || '';
  const cardLast4 = fullCard.slice(-4);
  const cardFirst12 = fullCard.slice(0, 12);

  const cardHash = await bcrypt.hash(cardFirst12, 10);
  const cvvHash = await bcrypt.hash(cvv, 10);

  const user = new User({
    username,
    password: hashed,
    forename,
    surname,
    phone,
    category: "observer",
    cardInfo: {
      accountName: req.body.accountName,
      accountNumber: req.body.accountNumber,
      sortCode: req.body.sortCode,
      cardLast4,
      cardHash,
      cvvHash
    },
  });

  await user.save();
  res.redirect("/login");
});


// Login
router.get("/login", (req, res) => {
  res.render("auth/login");
});

router.post("/login", async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.render("auth/login", { error: "Invalid credentials" });
  }
  if (!user.isActive) {
    return res.render("auth/login", {
      error: "Your account is disabled. Please contact support.",
    });
  }

  req.session.user = {
    _id: user._id,
    username: user.username,
    category: user.category,
  };

  res.redirect("/observer/dashboard");
});

// Logout
router.get("/logout", (req, res) => {
  req.session.destroy(() => res.redirect("/login"));
});

module.exports = router;
