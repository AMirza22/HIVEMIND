const express = require("express");
const router = express.Router();
const User = require("../models/User");
const { isAuthenticated } = require("../middleware/authMiddleware");
const bcrypt = require("bcrypt");

// View account details
router.get("/", isAuthenticated, async (req, res) => {
  const user = await User.findById(req.session.user._id);
  res.render("auth/account", { user });
});

// Show edit account form
router.get("/edit", isAuthenticated, async (req, res) => {
  const user = await User.findById(req.session.user._id);
  res.render("auth/edit-account", { user });
});

router.post("/edit", isAuthenticated, async (req, res) => {
  const {
    forename,
    surname,
    phone,
    line1,
    line2,
    line3,
    postcode,
    city,
    country,
    accountName,
    accountNumber,
    sortCode,
    cardNumber,
    cvv
  } = req.body;

  const updateFields = {
    forename,
    surname,
    phone,
    line1,
    line2,
    line3,
    postcode,
    city,
    country,
  };

  if (req.session.user.category === "observer") {
    const cardInfo = {
      accountName,
      accountNumber,
      sortCode,
    };

    // Only hash and update cardNumber/CVV if new values were entered
    if (cardNumber && cardNumber.length === 16) {
      const cardLast4 = cardNumber.slice(-4);
      const cardFirst12 = cardNumber.slice(0, 12);
      cardInfo.cardLast4 = cardLast4;
      cardInfo.cardHash = await bcrypt.hash(cardFirst12, 10);
    }

    if (cvv && cvv.length === 3) {
      cardInfo.cvvHash = await bcrypt.hash(cvv, 10);
    }

    updateFields.cardInfo = cardInfo;
  }

  await User.findByIdAndUpdate(req.session.user._id, updateFields);
  const updatedUser = await User.findById(req.session.user._id);
  req.session.user = {
    _id: updatedUser._id,
    username: updatedUser.username,
    category: updatedUser.category,
  };

  res.redirect("/account");
});


// Show change password form
router.get("/change-password", isAuthenticated, (req, res) => {
  res.render("auth/change-password", {
    error: null,
    user: req.session.user
  });
});

router.post("/change-password", isAuthenticated, async (req, res) => {
  const { currentPassword, newPassword, confirmPassword } = req.body;

  console.log("REQ BODY:", req.body); // ✅ TEMP DEBUG
  const user = await User.findById(req.session.user._id);

  // Ensure user and hashed password exist
  if (!user || !user.password) {
    return res.render("auth/change-password", {
      error: "❌ User account is invalid.",
      user: req.session.user
    });
  }

  const passwordMatches = await bcrypt.compare(currentPassword, user.password);
  if (!passwordMatches) {
    return res.render("auth/change-password", {
      error: "❌ Current password is incorrect.",
      user: req.session.user
    });
  }

  if (newPassword !== confirmPassword) {
    return res.render("auth/change-password", {
      error: "❌ New passwords do not match.",
      user: req.session.user
    });
  }

  const hashed = await bcrypt.hash(newPassword, 10);
  user.password = hashed;
  await user.save();

  res.redirect("/account");
});


module.exports = router;
