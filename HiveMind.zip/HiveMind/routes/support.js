const express = require("express");
const router = express.Router();
const Ticket = require("../models/Ticket");
const User = require("../models/User");
const Observation = require("../models/Observation");
const { isAuthenticated, isSupport } = require("../middleware/authMiddleware");
const bcrypt = require("bcrypt");
const Message = require("../models/Message");

router.get("/dashboard", isAuthenticated, isSupport, async (req, res) => {
  try {
    const unpaidObservations = await Observation.find({ "payment.status": false })
      .populate("observerId")
      .sort({ createdAt: -1 })
      .limit(3);

    const openTickets = await Ticket.find({ status: "open" })
      .populate("observerId")
      .sort({ createdAt: -1 })
      .limit(3);

    const recentMessages = await Message.find()
      .populate("from to")
      .sort({ sentAt: -1 })
      .limit(3);

    res.render("support/dashboard", {
      user: req.session.user,
      unpaidObservations,
      openTickets,
      recentMessages
    });
  } catch (err) {
    console.error("Error loading dashboard:", err);
    res.status(500).send("Internal Server Error");
  }
});

// Tickets
router.get("/tickets", isAuthenticated, isSupport, async (req, res) => {
  const tickets = await Ticket.find().populate("observerId").sort({ createdAt: -1 });
  res.render("support/ticket-list", { tickets });
});

router.get("/tickets/:id", isAuthenticated, isSupport, async (req, res) => {
  const ticket = await Ticket.findById(req.params.id).populate("observerId");
  res.render("support/view-ticket", { ticket });
});

router.post("/tickets/:id/reply", isAuthenticated, isSupport, async (req, res) => {
  const ticket = await Ticket.findById(req.params.id);
  if (!ticket) return res.status(404).send("Ticket not found");

  ticket.replies.push({
    senderName: req.session.user.username,
    message: req.body.message,
    sentAt: new Date(),
  });

  ticket.updatedAt = new Date();
  await ticket.save();
  res.redirect(`/support/tickets/${ticket._id}`);
});

router.post("/tickets/:id/close", isAuthenticated, isSupport, async (req, res) => {
  const ticket = await Ticket.findById(req.params.id);
  ticket.status = "closed";
  ticket.updatedAt = new Date();
  await ticket.save();
  res.redirect(`/support/tickets/${ticket._id}`);
});

// User Management
router.get("/users", isAuthenticated, isSupport, async (req, res) => {
  const observers = await User.find({ category: "observer" }).sort({ username: 1 });
  res.render("support/user-list", { observers });
});

router.post("/users/:id/toggle", isAuthenticated, isSupport, async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).send("User not found");

  user.isActive = !user.isActive;
  await user.save();

  res.redirect("/support/users");
});

// Create Support User
router.get("/create-user", isAuthenticated, isSupport, (req, res) => {
  res.render("support/create-user", { error: null });
});

router.post("/create-user", isAuthenticated, isSupport, async (req, res) => {
  const { username, password, forename, surname, phone } = req.body;

  try {
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.render("support/create-user", { error: "User already exists." });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = new User({
      username,
      password: hashedPassword,
      forename,
      surname,
      phone,
      category: "support",
      isActive: true,
    });

    await newUser.save();
    res.redirect("/support/dashboard");
  } catch (err) {
    res.render("support/create-user", { error: "Error creating user: " + err.message });
  }
});

// Observation Payment (only support)
router.get("/observations/:id/payment", isAuthenticated, async (req, res) => {
  if (req.session.user.category !== "support") return res.status(403).send("Forbidden");

  const observation = await Observation.findById(req.params.id).populate("observerId");
  if (!observation) return res.status(404).send("Observation not found");

  res.render("support/edit-payment", { observation, user: req.session.user });
});

router.post("/observations/:id/payment", isAuthenticated, async (req, res) => {
  if (req.session.user.category !== "support") return res.status(403).send("Forbidden");

  const { paymentStatus, paymentAmount } = req.body;

  await Observation.findByIdAndUpdate(req.params.id, {
    payment: {
      status: paymentStatus === "true",
      amount: parseFloat(paymentAmount),
      paymentDate: new Date(),
    },
  });

  res.redirect("/observations");
});

module.exports = router;
