const express = require("express");
const router = express.Router();
const { isAuthenticated, isObserver } = require("../middleware/authMiddleware");
const Observation = require("../models/Observation");
const Ticket = require("../models/Ticket");
const Message = require("../models/Message");

// Observer Dashboard
router.get("/dashboard", isAuthenticated, isObserver, async (req, res) => {
  try {
    const observations = await Observation.find({ observerId: req.session.user._id })
      .sort({ createdAt: -1 });

    const unpaidObservations = await Observation.find({
      observerId: req.session.user._id,
      "payment.status": false,
    })
      .sort({ createdAt: -1 })
      .limit(3);

    const recentMessages = await Message.find({
      $or: [
        { from: req.session.user._id },
        { to: req.session.user._id },
      ]
    })
      .populate("from to")
      .sort({ sentAt: -1 })
      .limit(3);

    res.render("observer/dashboard", {
      user: req.session.user,
      observations,
      unpaidObservations,
      recentMessages
    });
  } catch (err) {
    console.error("Dashboard load error:", err);
    res.status(500).send("Internal server error.");
  }
});


// New Observation
router.get("/observation/new", isAuthenticated, (req, res) => {
  res.render("observer/new-observation", {
    w3wApiKey: process.env.W3W_API_KEY,
  });
});

// Submit Observation
router.post("/observation/new", isAuthenticated, isObserver, async (req, res) => {
  const { w3w, lat, lng, date, time, timeZoneOffset, ...rest } = req.body;
  const fullDate = new Date(`${date}T${time}`);

  const obs = new Observation({
    observerId: req.session.user._id,
    w3w,
    coordinates:
      lat && lng && !isNaN(parseFloat(lat)) && !isNaN(parseFloat(lng))
        ? { lat: parseFloat(lat), lng: parseFloat(lng) }
        : undefined,
    date: fullDate,
    timeZoneOffset,
    ...rest,
  });

  await obs.save();
  res.redirect("/observer/dashboard");
});

// Edit Observation
router.get("/observation/:id/edit", isAuthenticated, isObserver, async (req, res) => {
  const observation = await Observation.findOne({
    _id: req.params.id,
    observerId: req.session.user._id,
  });

  if (!observation) {
    return res.status(404).send("Observation not found or not authorized.");
  }

  res.render("observer/edit-observation", {
    observation,
    w3wApiKey: process.env.W3W_API_KEY,
  });
});

// Edit Observation
router.post("/observation/:id/edit", isAuthenticated, isObserver, async (req, res) => {
  const observation = await Observation.findOne({
    _id: req.params.id,
    observerId: req.session.user._id,
  });

  if (!observation) {
    return res.status(404).send("Observation not found");
  }

  observation.editHistory.push({ editedAt: new Date() });

  const { lat, lng, ...rest } = req.body;
  Object.assign(observation, rest);

  observation.coordinates =
    lat && lng && !isNaN(parseFloat(lat)) && !isNaN(parseFloat(lng))
      ? { lat: parseFloat(lat), lng: parseFloat(lng) }
      : undefined;

  await observation.save();
  res.redirect(`/observations/${observation._id}`);
});

// Delete Observation
router.post("/observation/:id/delete", isAuthenticated, isObserver, async (req, res) => {
  const deleted = await Observation.findOneAndDelete({
    _id: req.params.id,
    observerId: req.session.user._id,
  });

  if (!deleted) {
    return res.status(404).send("Observation not found or not authorized to delete.");
  }

  res.redirect("/observations");
});

// Tickets
router.get("/ticket/new", isAuthenticated, isObserver, (req, res) => {
  res.render("observer/new-ticket");
});

router.post("/ticket/new", isAuthenticated, isObserver, async (req, res) => {
  const ticket = new Ticket({
    observerId: req.session.user._id,
    subject: req.body.subject,
    description: req.body.description,
  });

  await ticket.save();
  res.redirect("/observer/tickets");
});

router.get("/tickets", isAuthenticated, isObserver, async (req, res) => {
  const tickets = await Ticket.find({ observerId: req.session.user._id }).sort({
    createdAt: -1,
  });
  res.render("observer/ticket-list", { tickets });
});

router.get("/tickets/:id", isAuthenticated, isObserver, async (req, res) => {
  const ticket = await Ticket.findOne({
    _id: req.params.id,
    observerId: req.session.user._id,
  });

  if (!ticket) {
    return res.status(404).send("Ticket not found or not authorized.");
  }

  res.render("observer/view-ticket", { ticket });
});

module.exports = router;
