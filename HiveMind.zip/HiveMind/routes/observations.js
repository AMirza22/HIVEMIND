const express = require("express");
const router = express.Router();
const Observation = require("../models/Observation");
const { isAuthenticated } = require("../middleware/authMiddleware");

// GET /observations – shared list
router.get("/", isAuthenticated, async (req, res) => {
  const user = req.session.user;
  let observations;

  try {
    if (user.category === "support") {
      observations = await Observation.find()
        .populate("observerId")
        .sort({ createdAt: -1 });
    } else if (user.category === "observer") {
      observations = await Observation.find({ observerId: user._id }).sort({ createdAt: -1 });
    } else {
      return res.status(403).send("Unauthorized access.");
    }

    res.render("observations/list", { observations, user });

  } catch (err) {
    console.error("Failed to load observations:", err);
    res.status(500).send("Server error while fetching observations.");
  }
});

// GET /observations/:id – detail view
router.get("/:id", isAuthenticated, async (req, res) => {
  const user = req.session.user;

  try {
    const observation = await Observation.findById(req.params.id).populate("observerId");

    if (!observation) {
      return res.status(404).send("Observation not found.");
    }

    // Observer role can only view their own observation
    if (user.category === "observer" && observation.observerId._id.toString() !== user._id) {
      return res.status(403).send("Access denied.");
    }

    res.render("observations/details", { observation, user });

  } catch (err) {
    console.error("Failed to load observation detail:", err);
    res.status(500).send("Server error while fetching observation detail.");
  }
});

module.exports = router;
