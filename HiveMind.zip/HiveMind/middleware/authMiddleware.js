function isAuthenticated(req, res, next) {
    if (req.session.user) return next();
    res.redirect('/login');
  }
  
  function isObserver(req, res, next) {
    if (req.session.user?.category === 'observer') return next();
    res.redirect('/');
  }

  function isSupport(req, res, next) {
    if (req.session.user?.category === 'support') return next();
    res.redirect('/');
  }
  
  module.exports = { isAuthenticated, isObserver, isSupport };
  