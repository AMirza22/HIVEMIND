const User = require("../models/User");

describe("User Model", () => {
  it("should have required fields", () => {
    const user = new User({
      username: "test@test.com",
      password: "hashed",
      category: "observer",
      forename: "John",
      surname: "Doe"
    });

    expect(user.username).toBe("test@test.com");
    expect(user.category).toBe("observer");
    expect(user.cardInfo).toBeDefined();
  });
});
