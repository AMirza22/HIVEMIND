const mockRequest = (category) => ({
  session: { user: { category } }
});

describe("Role Middleware", () => {
  it("should detect observer", () => {
    const req = mockRequest("observer");
    expect(req.session.user.category).toBe("observer");
  });

  it("should detect support", () => {
    const req = mockRequest("support");
    expect(req.session.user.category).toBe("support");
  });
});
