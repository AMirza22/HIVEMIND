const bcrypt = require("bcrypt");

describe("Card Info Hashing", () => {
  const cardNumber = "1234567890123456"; // 16 digits
  const cvv = "123";

  it("should extract last 4 digits", () => {
    const last4 = cardNumber.slice(-4);
    expect(last4).toBe("3456");
  });

  it("should hash first 12 digits and validate it", async () => {
    const first12 = cardNumber.slice(0, 12);
    const hash = await bcrypt.hash(first12, 10);
    const match = await bcrypt.compare("123456789012", hash);
    expect(match).toBe(true);
  });

  it("should hash CVV correctly", async () => {
    const hash = await bcrypt.hash(cvv, 10);
    const match = await bcrypt.compare("123", hash);
    expect(match).toBe(true);
  });
});
