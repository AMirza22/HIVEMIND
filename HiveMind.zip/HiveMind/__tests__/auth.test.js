const bcrypt = require("bcrypt");

describe("Password Security", () => {
  it("should hash and verify passwords correctly", async () => {
    const plain = "Test123!";
    const hash = await bcrypt.hash(plain, 10);
    expect(await bcrypt.compare(plain, hash)).toBe(true);
  });

  it("should fail verification on wrong password", async () => {
    const hash = await bcrypt.hash("Test123!", 10);
    expect(await bcrypt.compare("WrongPass", hash)).toBe(false);
  });
});
