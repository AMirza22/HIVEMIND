const bcrypt = require("bcrypt");

describe("Card Info Processing", () => {
  const card = "1234567890123456";
  const cvv = "123";

  it("should extract last 4 digits", () => {
    expect(card.slice(-4)).toBe("3456");
  });

  it("should hash first 12 digits and verify", async () => {
    const part = card.slice(0, 12);
    const hash = await bcrypt.hash(part, 10);
    expect(await bcrypt.compare("123456789012", hash)).toBe(true);
  });

  it("should hash and verify CVV", async () => {
    const hash = await bcrypt.hash(cvv, 10);
    expect(await bcrypt.compare("123", hash)).toBe(true);
  });
});
