const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  forename: String,
  surname: String,
  phone: String,
  category: { type: String, enum: ["observer", "support"], required: true },
  status: {
    type: String,
    enum: ["active", "inactive", "suspended"],
    default: "active",
  },
  isActive: { type: Boolean, default: true },

  // Only relevant for observers:
  line1: { type: String, default: "" },
  line2: { type: String, default: "" },
  line3: { type: String, default: "" },
  postcode: { type: String, default: "" },
  city: { type: String, default: "" },
  country: { type: String, default: "" },

  cardInfo: {
    accountName: { type: String, default: "" },
    accountNumber: { type: String, default: "" },
    sortCode: { type: String, default: "" },
    cardLast4: { type: String }, // last 4 digits of card
    cardHash: { type: String }, // hashed first 12 digits
    cvvHash: { type: String }, // hashed CVV
  },
});

module.exports = mongoose.model("User", userSchema);
