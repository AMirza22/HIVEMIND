const mongoose = require('mongoose');

const ticketSchema = new mongoose.Schema({
  observerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  subject: String,
  description: String,
  status: { type: String, enum: ['open', 'closed'], default: 'open' },
  replies: [{
    senderType: { type: String, enum: ['observer', 'support'] },
    message: String,
    sentAt: { type: Date, default: Date.now }
  }],
  createdAt: { type: Date, default: Date.now },
  updatedAt: Date,
  replies: [{
    senderName: String,
    message: String,
    sentAt: { type: Date, default: Date.now }
  }]
  
});

module.exports = mongoose.model('Ticket', ticketSchema);
