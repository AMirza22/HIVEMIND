const mongoose = require('mongoose');

const observationSchema = new mongoose.Schema({
  observerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  w3w: String,
  coordinates: {
    lat: Number,
    lng: Number
  },
  freeSpacePathLoss: String,
  ber: String,
  temperature: String,
  humidity: String,
  snowfall: String,
  windSpeed: String,
  windDirection: String,
  precipitation: String,
  haze: String,
  notes: String,
  date: { type: Date },
  timeZoneOffset: String,
  editHistory: [{
    editedAt: Date
  }],
  payment: {
  status: { type: Boolean, default: false },
  amount: { type: Number, default: 0 },
  paymentDate: Date
}

  
}, { timestamps: true });


module.exports = mongoose.model('Observation', observationSchema);
